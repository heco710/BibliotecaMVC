@echo off
cd /d "%~dp0BibliotecaMVC"
where dotnet >nul 2>nul
if errorlevel 1 (echo Instale .NET SDK 10.0.302. & pause & exit /b 1)
echo Prepare BibliotecaDB siguiendo README.md antes de ejecutar.
dotnet run --launch-profile http
pause
